﻿using TMPro;
using UnityEngine;

namespace Script.Dev.UI
{
    public class ContentContainer: MonoBehaviour
    {
        [SerializeField]
        private TMP_Text m_Output;

        public void AppendText(string str)
        {
            m_Output.text += $"\n{str}";
        }

        public void ClearText()
        {
            m_Output.text = null;
        }
    }
}