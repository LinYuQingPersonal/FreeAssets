﻿using System;
using TMPro;
using UnityEngine;
using UnityEngine.Events;

namespace Script.Dev.UI
{
    public class DevConsolePanel: MonoBehaviour
    {
        [SerializeField]
        private ContentContainer m_ContentContainer;
        [SerializeField]
        private InputContainer m_InputContainer;

        private UnityAction m_ClearAction;
        private void Awake()
        {
            m_ClearAction = m_ContentContainer.ClearText;
            m_InputContainer.Initialize(OnSubmitCommand,m_ClearAction);
        }

        private void OnSubmitCommand(string cmd)
        {
            if (string.IsNullOrWhiteSpace(cmd))
            {
                return;
            }
            m_ContentContainer.AppendText(cmd);
        }
    }
}