
using TMPro;
using UnityEngine;

public class TextSizeFitter : MonoBehaviour
{
    [SerializeField]
    private TMP_Text m_Text;
    [SerializeField]
    private RectTransform m_TransformToFit;

    private Vector2 m_SizeDelta;
    private float m_MoveDeltaYAxis;
    private void FixedUpdate()
    {
        m_SizeDelta=m_TransformToFit.sizeDelta;
        
        
        m_MoveDeltaYAxis=m_SizeDelta.y - m_Text.renderedHeight;
        
        m_SizeDelta.y = m_Text.renderedHeight;
        


        var anchoredPosition = m_TransformToFit.anchoredPosition;
        anchoredPosition.y -= m_MoveDeltaYAxis;
        m_TransformToFit.anchoredPosition = anchoredPosition;
        
        m_TransformToFit.sizeDelta = m_SizeDelta;
    }
}
