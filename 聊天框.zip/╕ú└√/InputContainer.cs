﻿using System;
using TMPro;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.InputSystem;
using UnityEngine.UI;

namespace Script.Dev.UI
{
    public class InputContainer: MonoBehaviour
    {
        [SerializeField]
        private Button m_ClearButton;

        [SerializeField] 
        private TMP_InputField m_InputField;
 
        // [SerializeField,Header("Debugging Values")]
        // private bool focus;
        // [SerializeField]
        // private bool input;

        public void Initialize(UnityAction<string> onSubmitCommand,UnityAction onClicked)
        {           
            m_InputField.onSubmit.AddListener((string str) =>
            {
                m_InputField.ActivateInputField();
                onSubmitCommand(str);
                m_InputField.text=null; 
            });
            
            m_ClearButton.onClick.AddListener(onClicked);
        }


        // private bool EnterPressed()
        // {
        //     return Keyboard.current.enterKey.wasPressedThisFrame;
        // }
        //
        // private bool IsFocusOn()
        // {
        //     return EventSystem.current.currentSelectedGameObject == m_InputField.gameObject;
        // }

    }
}